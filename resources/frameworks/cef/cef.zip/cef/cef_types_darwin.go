//----------------------------------------
//
// Copyright © yanghy. All Rights Reserved.
//
// Licensed under Apache License 2.0
//
//----------------------------------------

//go:build darwin
// +build darwin

package cef

import (
	cefTypes "github.com/energye/cef/types"
	"github.com/energye/lcl/api"
)

type TCefAcceleratedPaintInfo struct {
	SharedTextureIoSurface cefTypes.TCefSharedTextureHandle // TCefSharedTextureHandle
	Format                 cefTypes.TCefColorType           // TCefColorType
}

type TCefWindowInfo struct {
	WindowName                 string                    // TCefString
	Bounds                     TCefRect                  // TCefRect
	Hidden                     int32                     // Integer
	ParentView                 cefTypes.TCefWindowHandle // TCefWindowHandle
	WindowlessRenderingEnabled int32                     // Integer
	SharedTextureEnabled       int32                     // Integer
	ExternalBeginFrameEnabled  int32                     // Integer
	View                       cefTypes.TCefWindowHandle // TCefWindowHandle
	RuntimeStyle               cefTypes.TCefRuntimeStyle // TCefRuntimeStyle
}

func (m *TCefAcceleratedPaintInfo) ToPas() *tCefAcceleratedPaintInfo {
	if m == nil {
		return nil
	}
	return &tCefAcceleratedPaintInfo{
		SharedTextureIoSurface: m.SharedTextureIoSurface,
		Format:                 m.Format,
	}
}

type tCefAcceleratedPaintInfo struct {
	SharedTextureIoSurface cefTypes.TCefSharedTextureHandle // TCefSharedTextureHandle
	Format                 cefTypes.TCefColorType           // TCefColorType
}

func (m *tCefAcceleratedPaintInfo) ToGo() TCefAcceleratedPaintInfo {
	if m == nil {
		return TCefAcceleratedPaintInfo{}
	}
	return TCefAcceleratedPaintInfo{
		SharedTextureIoSurface: m.SharedTextureIoSurface,
		Format:                 m.Format,
	}
}
func (m *TCefWindowInfo) ToPas() *tCefWindowInfo {
	if m == nil {
		return nil
	}
	return &tCefWindowInfo{
		WindowName:                 api.PasStr(m.WindowName),
		Bounds:                     m.Bounds,
		Hidden:                     m.Hidden,
		ParentView:                 m.ParentView,
		WindowlessRenderingEnabled: m.WindowlessRenderingEnabled,
		SharedTextureEnabled:       m.SharedTextureEnabled,
		ExternalBeginFrameEnabled:  m.ExternalBeginFrameEnabled,
		View:                       m.View,
		RuntimeStyle:               m.RuntimeStyle,
	}
}

type tCefWindowInfo struct {
	WindowName                 uintptr                   // TCefString
	Bounds                     TCefRect                  // TCefRect
	Hidden                     int32                     // Integer
	ParentView                 cefTypes.TCefWindowHandle // TCefWindowHandle
	WindowlessRenderingEnabled int32                     // Integer
	SharedTextureEnabled       int32                     // Integer
	ExternalBeginFrameEnabled  int32                     // Integer
	View                       cefTypes.TCefWindowHandle // TCefWindowHandle
	RuntimeStyle               cefTypes.TCefRuntimeStyle // TCefRuntimeStyle
}

func (m *tCefWindowInfo) ToGo() TCefWindowInfo {
	if m == nil {
		return TCefWindowInfo{}
	}
	return TCefWindowInfo{
		WindowName:                 api.GoStr(m.WindowName),
		Bounds:                     m.Bounds,
		Hidden:                     m.Hidden,
		ParentView:                 m.ParentView,
		WindowlessRenderingEnabled: m.WindowlessRenderingEnabled,
		SharedTextureEnabled:       m.SharedTextureEnabled,
		ExternalBeginFrameEnabled:  m.ExternalBeginFrameEnabled,
		View:                       m.View,
		RuntimeStyle:               m.RuntimeStyle,
	}
}
