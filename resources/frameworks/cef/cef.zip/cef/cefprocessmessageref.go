//----------------------------------------
//
// Copyright © yanghy. All Rights Reserved.
//
// Licensed under Apache License 2.0
//
//----------------------------------------

package cef

import (
	"github.com/energye/lcl/api"
	"github.com/energye/lcl/api/imports"
	"github.com/energye/lcl/base"
)

// ICefProcessMessage Parent: ICefBaseRefCounted
type ICefProcessMessage interface {
	ICefBaseRefCounted
	// IsValid
	//  Returns true (1) if this object is valid. Do not call any other functions
	//  if this function returns false (0).
	IsValid() bool // function
	// IsReadOnly
	//  Returns true (1) if the values of this object are read-only. Some APIs may
	//  expose read-only objects.
	IsReadOnly() bool // function
	// Copy
	//  Returns a writable copy of this object. Returns nullptr when message
	//  contains a shared memory region.
	Copy() ICefProcessMessage // function
	// GetName
	//  Returns the message name.
	GetName() string // function
	// GetArgumentList
	//  Returns the list of arguments. Returns nullptr when message contains a
	//  shared memory region.
	GetArgumentList() ICefListValue // function
	// GetSharedMemoryRegion
	//  Returns the shared memory region. Returns nullptr when message contains an
	//  argument list.
	GetSharedMemoryRegion() ICefSharedMemoryRegion // function
}

// ICefProcessMessageRef Parent: ICefProcessMessage ICefBaseRefCountedRef
type ICefProcessMessageRef interface {
	ICefProcessMessage
	ICefBaseRefCountedRef
	AsIntfProcessMessage() uintptr
}

type TCefProcessMessageRef struct {
	TCefBaseRefCountedRef
}

func (m *TCefProcessMessageRef) IsValid() bool {
	if !m.TBase.IsValid() {
		return false
	}
	r := cefProcessMessageRefAPI().SysCallN(1, m.Instance())
	return api.GoBool(r)
}

func (m *TCefProcessMessageRef) IsReadOnly() bool {
	if !m.IsValid() {
		return false
	}
	r := cefProcessMessageRefAPI().SysCallN(2, m.Instance())
	return api.GoBool(r)
}

func (m *TCefProcessMessageRef) Copy() (result ICefProcessMessage) {
	if !m.IsValid() {
		return
	}
	var resultPtr uintptr
	cefProcessMessageRefAPI().SysCallN(3, m.Instance(), uintptr(base.UnsafePointer(&resultPtr)))
	result = AsCefProcessMessageRef(resultPtr)
	return
}

func (m *TCefProcessMessageRef) GetName() string {
	if !m.IsValid() {
		return ""
	}
	r := cefProcessMessageRefAPI().SysCallN(4, m.Instance())
	return api.GoStr(r)
}

func (m *TCefProcessMessageRef) GetArgumentList() (result ICefListValue) {
	if !m.IsValid() {
		return
	}
	var resultPtr uintptr
	cefProcessMessageRefAPI().SysCallN(5, m.Instance(), uintptr(base.UnsafePointer(&resultPtr)))
	result = AsCefListValueRef(resultPtr)
	return
}

func (m *TCefProcessMessageRef) GetSharedMemoryRegion() (result ICefSharedMemoryRegion) {
	if !m.IsValid() {
		return
	}
	var resultPtr uintptr
	cefProcessMessageRefAPI().SysCallN(6, m.Instance(), uintptr(base.UnsafePointer(&resultPtr)))
	result = AsCefSharedMemoryRegionRef(resultPtr)
	return
}

func (m *TCefProcessMessageRef) AsIntfProcessMessage() uintptr {
	return m.GetIntfPointer(0)
}

// ProcessMessageRef  is static instance
var ProcessMessageRef _ProcessMessageRefClass

// _ProcessMessageRefClass is class type defined by TCefProcessMessageRef
type _ProcessMessageRefClass uintptr

func (_ProcessMessageRefClass) UnWrap(data uintptr) (result ICefProcessMessage) {
	var resultPtr uintptr
	cefProcessMessageRefAPI().SysCallN(7, uintptr(data), uintptr(base.UnsafePointer(&resultPtr)))
	result = AsCefProcessMessageRef(resultPtr)
	return
}

func (_ProcessMessageRefClass) New(name string) (result ICefProcessMessage) {
	var resultPtr uintptr
	cefProcessMessageRefAPI().SysCallN(8, api.PasStr(name), uintptr(base.UnsafePointer(&resultPtr)))
	result = AsCefProcessMessageRef(resultPtr)
	return
}

// NewProcessMessageRef class constructor
func NewProcessMessageRef(data uintptr) ICefProcessMessageRef {
	var processMessagePtr uintptr // ICefProcessMessage
	r := cefProcessMessageRefAPI().SysCallN(0, uintptr(data), uintptr(base.UnsafePointer(&processMessagePtr)))
	ret := AsCefProcessMessageRef(r)
	if intf, ok := ret.(base.IIntfs); ok {
		intf.Create(1)
		intf.SetIntfPointer(0, processMessagePtr)
	}
	return ret
}

var (
	cefProcessMessageRefOnce   base.Once
	cefProcessMessageRefImport *imports.Imports = nil
)

func cefProcessMessageRefAPI() *imports.Imports {
	cefProcessMessageRefOnce.Do(func() {
		cefProcessMessageRefImport = api.NewDefaultImports()
		cefProcessMessageRefImport.Table = []*imports.Table{
			/* 0 */ imports.NewTable("TCefProcessMessageRef_Create", 0), // constructor NewProcessMessageRef
			/* 1 */ imports.NewTable("TCefProcessMessageRef_IsValid", 0), // function IsValid
			/* 2 */ imports.NewTable("TCefProcessMessageRef_IsReadOnly", 0), // function IsReadOnly
			/* 3 */ imports.NewTable("TCefProcessMessageRef_Copy", 0), // function Copy
			/* 4 */ imports.NewTable("TCefProcessMessageRef_GetName", 0), // function GetName
			/* 5 */ imports.NewTable("TCefProcessMessageRef_GetArgumentList", 0), // function GetArgumentList
			/* 6 */ imports.NewTable("TCefProcessMessageRef_GetSharedMemoryRegion", 0), // function GetSharedMemoryRegion
			/* 7 */ imports.NewTable("TCefProcessMessageRef_UnWrap", 0), // static function UnWrap
			/* 8 */ imports.NewTable("TCefProcessMessageRef_New", 0), // static function New
		}
	})
	return cefProcessMessageRefImport
}
