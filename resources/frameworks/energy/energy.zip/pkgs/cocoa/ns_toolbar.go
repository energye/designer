//----------------------------------------
//
// Copyright © yanghy. All Rights Reserved.
//
// Licensed under Apache License Version 2.0, January 2004
//
// https://www.apache.org/licenses/LICENSE-2.0
//
//----------------------------------------

//go:build darwin

package cocoa

/*
#cgo CFLAGS: -mmacosx-version-min=10.15 -x objective-c
#cgo LDFLAGS: -mmacosx-version-min=10.15 -framework Cocoa

#include "Cocoa/Cocoa.h"
#include "ns_toolbar.h"

*/
import "C"
import (
	"unsafe"
)

func NewToolBar(window, delegate unsafe.Pointer, config ToolbarConfiguration) {
	if window == nil {
		return
	}
	cConfig := ToolbarConfigurationToOC(config)
	C.CreateToolbar(window, delegate, cConfig)
}
