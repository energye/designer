//----------------------------------------
//
// Copyright © yanghy. All Rights Reserved.
//
// Licensed under Apache License Version 2.0, January 2004
//
// https://www.apache.org/licenses/LICENSE-2.0
//
//----------------------------------------

//go:build darwin

package window

/*
#cgo darwin CFLAGS: -DDARWIN -x objective-c
#cgo darwin LDFLAGS: -framework Cocoa
*/
import "C"
import (
	"github.com/energye/lcl/lcl"
	"sync"
	"unsafe"
)

//export GoLog
func GoLog(message *C.char) {
	msg := C.GoString(message)
	println(msg)
}

//export CanDrag
func CanDrag(nsWindow unsafe.Pointer) bool {
	var window = currentWindow(lcl.NSWindow(nsWindow))
	if window != nil {
		//return window.drag.canDrag
	}
	return false
}

//export SetCanDrag
func SetCanDrag(nsWindow unsafe.Pointer, value bool) {
	var window = currentWindow(lcl.NSWindow(nsWindow))
	if window != nil {
		//window.drag.canDrag = value
	}
}

//export GetTitlebarHeight
func GetTitlebarHeight(nsWindow unsafe.Pointer) int32 {
	var window = currentWindow(lcl.NSWindow(nsWindow))
	if window != nil {
		// TODO no impl
	}
	return 0
}

//export CheckDraggableRegions
func CheckDraggableRegions(nsWindow unsafe.Pointer, mouseX, mouseY int32) {
	var window = currentWindow(lcl.NSWindow(nsWindow))
	//fmt.Println("mouseX, mouseY", mouseX, mouseY, window)
	if window != nil {
		//window.drag.canDrag = false
		//regions := window.ChromiumBrowser().Regions()
		//if regions != nil {
		//	var isDrag bool
		//	for i := 0; i < regions.RegionsCount(); i++ {
		//		region := regions.Region(i)
		//		if region.Draggable {
		//			isDrag = PtInRegion(mouseX, mouseY, region.Bounds.X, region.Bounds.Y, region.Bounds.Width, region.Bounds.Height)
		//			if isDrag {
		//				break
		//			}
		//		}
		//	}
		//	if isDrag {
		//		for i := 0; i < regions.RegionsCount(); i++ {
		//			region := regions.Region(i)
		//			if !region.Draggable {
		//				tempIsDrag := PtInRegion(mouseX, mouseY, region.Bounds.X, region.Bounds.Y, region.Bounds.Width, region.Bounds.Height)
		//				if tempIsDrag {
		//					isDrag = false
		//					break
		//				}
		//			}
		//		}
		//	}
		//	window.drag.canDrag = isDrag
		//}
	}
}

var (
	gDarwinWindowCache = sync.Map{}
)

func currentWindow(windowHandle lcl.NSWindow) IDarwinWindow {
	tempWindow, ok := gDarwinWindowCache.Load(windowHandle)
	if ok {
		return tempWindow.(IDarwinWindow)
	}
	return nil
}
