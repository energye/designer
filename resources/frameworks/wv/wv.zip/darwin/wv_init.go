//----------------------------------------
//
// Copyright © yanghy. All Rights Reserved.
//
// Licensed under Apache License 2.0
//
//----------------------------------------

// :predefine:

package darwin

import (
	"github.com/energye/lcl/api"
)

// Init Webview2
func Init() {
	// 注册 Webkit 对象事件回调
	api.SetEventCallback(eventCallback, api.EctWV)
	// 注册 Webkit 对象事件回调移除
	api.SetEventCallback(removeEventCallback, api.EctWVRemove)

}
